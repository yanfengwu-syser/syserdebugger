#include "stdafx.h"
#ifdef CODE_OS_NT_DRV	
#define FILE MYFILE
typedef void MYFILE;
#undef stdout 
#undef stdin
#define stdout 0
#define stdin 0 
#endif
