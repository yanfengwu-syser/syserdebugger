compile environment

WINDOWS DDK (required) 
version:
    windows xp ddk 
    windows xpsp1 ddk
    windows ifsddk2003sp1

Microsoft Visual C++ (optional)

example:

if you user Microsoft vistual c++ IDE need set environment variable 
WXPBASE= "your windows ddk install path"
example: windows xpsp1 ddk default install path

WXPBASE=c:\winddk\2600.1106


How to install syser debugger plug-in module

copy plug-in module to c:\windows\system32\drivers\plugin\i386 directory.


