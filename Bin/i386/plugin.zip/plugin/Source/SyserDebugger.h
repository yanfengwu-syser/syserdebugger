#ifndef _SYSER_DEBUGGER_H_
#define _SYSER_DEBUGGER_H_

struct SYSER_CMD_ENTRY
{
	PCWSTR	CmdStr;
	PCWSTR	CmdCmt;
	void*	CmdProc;
	PCWSTR	CmdUsage;
};

struct SYSER_CMD_USAGE_ENTRY
{
	WCHAR*	CmdStr;
	WCHAR*	CmdCmt;
};

///////////////////////////////////////////////////////////////////////////////////////////////////
//Syser Debugger Plugin
typedef void	(*FPGetInfo)(CHAR*szInfo);
typedef void*	(*FPCreateDebugger)(void*UIObj);
typedef void	(*FPGetFileFilter)(WCHAR*szFilter);
//Syser Debugger Plugin
///////////////////////////////////////////////////////////////////////////////////////////////////

typedef void	(*PVFV) (void);

struct SYSER_PLUGIN_MODULE
{
	WCHAR			PluginInfo[32];
	PVFV			fpOnDebuggerOpen;
	PVFV			fpOnDebuggerClose;
	PVFV			fpOnDebuggerPlunge;
};

typedef void	(*FPMenuProc)();
typedef int	(*FPCmd)(int argc,PCWSTR argv[],PCWSTR szCommandLine,void*pUserData);

//Syser Plugin User Interfacer

class CSyserPluginUI
{
public:
	///////////////////////////////////////////////////////////////////////////////////////////////////
	//Plugin
	virtual	bool	RegisterPluginModule(PCWSTR ModuleName,SYSER_PLUGIN_MODULE*pPluginModule) = 0;
	virtual	bool	UnregisterPluginModule(PCWSTR ModuleName) = 0;
	//Plugin
	///////////////////////////////////////////////////////////////////////////////////////////////////
public:
	///////////////////////////////////////////////////////////////////////////////////////////////////
	//Instruction
	virtual int		GetInstrLen(DWORD Address) = 0;
	//Instruction
	///////////////////////////////////////////////////////////////////////////////////////////////////
public:
	///////////////////////////////////////////////////////////////////////////////////////////////////
	//Symbol
	virtual	bool	CalcExp(const WCHAR*szExp,DWORD*pResult) = 0;
	//Symbol
	///////////////////////////////////////////////////////////////////////////////////////////////////
public:
	///////////////////////////////////////////////////////////////////////////////////////////////////
	//Command
	virtual bool	InsertCmd(PCWSTR szCmd,FPCmd pCmdProc,void*pUserData,PCWSTR pComment,PCWSTR pUsage) = 0;
	virtual void	RemoveCmd(PCWSTR szCmd) = 0;
	virtual int		RunCmd(PCWSTR szCmd) = 0;
	virtual void	Outputf(PCWSTR szMsg,...) = 0;
	virtual void	Output(PCDSTR szMsg) = 0;
	//Command
	///////////////////////////////////////////////////////////////////////////////////////////////////
public:
	///////////////////////////////////////////////////////////////////////////////////////////////////
	//GUI
	virtual	void*	InsertMenu(void*hParentMenu,const WCHAR*szMenuName,FPMenuProc fpMenuProc) = 0;
	virtual	bool	RemoveMenu(void*hMenu) = 0;
	virtual	bool	EnableMenu(void*hMenu,bool bEnable) = 0;
	virtual	void*	GetMainTabWnd() = 0;
	virtual	void*	GetMainMenu() = 0;
	virtual	void*	GetWisp() = 0;
	//GUI
	///////////////////////////////////////////////////////////////////////////////////////////////////
};

#endif
