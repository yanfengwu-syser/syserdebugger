#ifndef _SPCOMMAND_H_
#define _SPCOMMAND_H_

NTSTATUS DriverEntry(IN PDRIVER_OBJECT DriverObject,IN PUNICODE_STRING RegistryPath);

#endif
